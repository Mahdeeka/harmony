=== Intentionally Blank ===
Contributors: Prox
Tags: Prox, rtl, bootstrap
Requires at least: 1.0
Tested up to: 1.0
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Blank Prox theme template.

== Description ==

Blank Prox theme template.

== Changelog ==

= 2.0 =
* Style using Bootstrap 4.0.


= 1.0 =
* Cusotm style.
