﻿
<?php get_header();?>

<div class="bg1 pb-5 sectionPadding3">
    <div class="container c16 py-md-5">
        <div class="row align-items-start justify-content-between">
            <div class="col-md-12 mmb20">
                <h1 class=" mcenter mb-0 fs60 Niloofar fbold"><?php echo the_title() ?></h1>
            </div>
            <div class="col-md-12 pt-md-5 mmb20">
                <div class="  "><?php echo the_content() ?></div>
            </div>

        </div>
    </div>
</div>

<?php get_footer();?>
